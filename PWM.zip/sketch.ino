int RedPin = 9;
//int bright = 255; // for highest brightness from led
//int bright = 0; //for lowest brightness
int bright = 50;

void setup() {
  // put your setup code here, to run once:
  pinMode(RedPin,OUTPUT);
}

void loop() {
  // put your main code here, to run repeatedly:
  analogWrite(RedPin,bright);
}