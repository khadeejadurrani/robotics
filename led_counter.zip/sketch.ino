  int yellow = 3;
  int green = 4;
  int blue = 5;
  int pink = 6;

void setup(){
  pinMode(yellow,OUTPUT);
  pinMode(green,OUTPUT);
  pinMode(blue,OUTPUT);
  pinMode(pink,OUTPUT);

  // digitalWrite(orange,LOW);
  // digitalWrite(green,LOW);
  // digitalWrite(blue,LOW);
  // digitalWrite(pink,LOW);

  // delay(1000);//delay for 1 second

  // digitalWrite(orange,LOW);
  // digitalWrite(green,LOW);
  // digitalWrite(blue,LOW);
  // digitalWrite(pink,HIGH);

  // delay(1000);//delay for 1 second

  // digitalWrite(orange,LOW);
  // digitalWrite(green,LOW);
  // digitalWrite(blue,HIGH);
  // digitalWrite(pink,LOW);

  // delay(1000);

  // digitalWrite(orange,LOW);
  // digitalWrite(green,LOW);
  // digitalWrite(blue,HIGH);
  // digitalWrite(pink,HIGH);

  // delay(1000);

  // digitalWrite(orange,LOW);
  // digitalWrite(green,HIGH);
  // digitalWrite(blue,LOW);
  // digitalWrite(pink,LOW);

  // delay(1000);

  // digitalWrite(orange,LOW);
  // digitalWrite(green,HIGH);
  // digitalWrite(blue,LOW);
  // digitalWrite(pink,HIGH);

  // delay(1000);

  // digitalWrite(orange,LOW);
  // digitalWrite(green,HIGH);
  // digitalWrite(blue,HIGH);
  // digitalWrite(pink,LOW);

  // delay(1000);

  // digitalWrite(orange,LOW);
  // digitalWrite(green,HIGH);
  // digitalWrite(blue,HIGH);
  // digitalWrite(pink,HIGH);

  // delay(1000);

  // digitalWrite(orange,HIGH);
  // digitalWrite(green,LOW);
  // digitalWrite(blue,LOW);
  // digitalWrite(pink,LOW);

  // delay(1000);

  // digitalWrite(orange,HIGH);
  // digitalWrite(green,LOW);
  // digitalWrite(blue,LOW);
  // digitalWrite(pink,HIGH);

  // delay(1000);

  // digitalWrite(orange,HIGH);
  // digitalWrite(green,LOW);
  // digitalWrite(blue,HIGH);
  // digitalWrite(pink,LOW);

  // delay(1000);

  // digitalWrite(orange,HIGH);
  // digitalWrite(green,LOW);
  // digitalWrite(blue,HIGH);
  // digitalWrite(pink,HIGH);

  // delay(1000);

  // digitalWrite(orange,HIGH);
  // digitalWrite(green,HIGH);
  // digitalWrite(blue,LOW);
  // digitalWrite(pink,LOW);

  // delay(1000);

  // digitalWrite(orange,HIGH);
  // digitalWrite(green,HIGH);
  // digitalWrite(blue,LOW);
  // digitalWrite(pink,HIGH);

  // delay(1000);

  // digitalWrite(orange,HIGH);
  // digitalWrite(green,HIGH);
  // digitalWrite(blue,HIGH);
  // digitalWrite(pink,LOW);

  // delay(1000);

  // digitalWrite(orange,HIGH);
  // digitalWrite(green,HIGH);
  // digitalWrite(blue,HIGH);
  // digitalWrite(pink,HIGH);

  }

void loop() {
  for(int n=0;n<=15;n++){
    //b = blue
    //g = gree
    //p = pink
    //y = yellow
    int b=bitRead(n,0);
    int g=bitRead(n,1);
    int p=bitRead(n,2);
    int y =bitRead(n,3);

    if (b==1){
      digitalWrite(blue, HIGH);
    }
    else{
      digitalWrite(blue, LOW);
    }


    if (g==1){
      digitalWrite(green, HIGH);
    }
    else{
      digitalWrite(green, LOW);
    }


    if (p==1){
      digitalWrite(pink, HIGH);
    }
    else{
      digitalWrite(pink, LOW);
    }


    if (y==1){
      digitalWrite(yellow, HIGH);
    }
    else{
      digitalWrite(yellow, LOW);
    }

    delay(1000);
  }

}
