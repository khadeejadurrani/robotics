# Day 6: Binary Counter with 4 LEDs

**Source:** Paul McWhorter, New Arduino Tutorials (binary + LED binary counter assignment)
**Tool:** Wokwi simulator

**What I built:** 4 LEDs that count from 0 to 15 in binary, then start again.

---

## Part 1: Binary

### Why computers use binary

A digital device is made of switches. Each switch can only be **ON** or **OFF**.
A computer chip has a huge number of these tiny switches.

- ON = **1**
- OFF = **0**

Anything can be turned into numbers, and any number can be written using only 0s and 1s.
Writing numbers with only 0 and 1 is called **binary** (base 2).

### Decimal vs binary

| | Decimal (normal numbers) | Binary |
|---|---|---|
| Digits used | 0 to 9 | only 0 and 1 |
| Called | base 10 | base 2 |
| Place values (right to left) | 1, 10, 100, 1000 ... | 1, 2, 4, 8, 16 ... |

In binary, every place is **double** the one to its right.

```
Place value:   8    4    2    1
Position:      3    2    1    0     ← count from the RIGHT, start at 0
```

### Key words

| Word | Meaning |
|---|---|
| **Bit** | One binary digit (one 0 or 1). One LED = one bit |
| **4 bits** | 4 digits → 16 combinations → can show 0 to 15 |
| **Byte** | 8 bits → 256 combinations → 0 to 255 |

Rule: **n bits can show 2ⁿ numbers.** 4 bits → 2 × 2 × 2 × 2 = 16 numbers (0 to 15).
To show 16 you need a 5th bit: 16 = **10000**.

### Binary → decimal

Add up the place values where there is a **1**.

```
Binary:        1    0    1    1
Place value:   8    4    2    1
               8 +  0 +  2 +  1  =  11
```

So **1011 = 11**.

### Decimal → binary

Start from the biggest place value and ask: *does it fit?*

Example: **13**
1. Does 8 fit in 13? **Yes** → write 1. Left: 13 − 8 = 5
2. Does 4 fit in 5? **Yes** → write 1. Left: 5 − 4 = 1
3. Does 2 fit in 1? **No** → write 0
4. Does 1 fit in 1? **Yes** → write 1. Left: 0

So **13 = 1101**.

### Counting table (0 to 15)

| Decimal | 8 | 4 | 2 | 1 | Binary |
|---|---|---|---|---|---|
| 0 | 0 | 0 | 0 | 0 | 0000 |
| 1 | 0 | 0 | 0 | 1 | 0001 |
| 2 | 0 | 0 | 1 | 0 | 0010 |
| 3 | 0 | 0 | 1 | 1 | 0011 |
| 4 | 0 | 1 | 0 | 0 | 0100 |
| 5 | 0 | 1 | 0 | 1 | 0101 |
| 6 | 0 | 1 | 1 | 0 | 0110 |
| 7 | 0 | 1 | 1 | 1 | 0111 |
| 8 | 1 | 0 | 0 | 0 | 1000 |
| 9 | 1 | 0 | 0 | 1 | 1001 |
| 10 | 1 | 0 | 1 | 0 | 1010 |
| 11 | 1 | 0 | 1 | 1 | 1011 |
| 12 | 1 | 1 | 0 | 0 | 1100 |
| 13 | 1 | 1 | 0 | 1 | 1101 |
| 14 | 1 | 1 | 1 | 0 | 1110 |
| 15 | 1 | 1 | 1 | 1 | 1111 |

**Pattern to notice:**
- The **1s** column flips every step (0,1,0,1 ...)
- The **2s** column flips every 2 steps
- The **4s** column flips every 4 steps
- The **8s** column flips every 8 steps

### Why an Arduino `int` stops at 32,767

On an Arduino Uno, an `int` uses **16 bits**. One bit is used for the **+ or − sign**, which leaves 15 bits for the number.
The biggest 15-bit number is 2¹⁵ − 1 = **32,767**. That's why `int` can't hold 40,000.

---

## Part 2: Wiring LEDs

### One LED circuit

```
Arduino pin → resistor → LED A (long leg, +) → LED C (short leg, −) → GND rail → Arduino GND
```

- **A = anode** = long, bent leg = **+** side
- **C = cathode** = short, straight leg = **−** side
- If the LED is backwards, it won't light.

### Rules I learned

1. **One LED = one resistor.** The resistor limits the current so the LED doesn't burn.
2. **The resistor can go before OR after the LED.** In a single loop (a **series circuit**), the same current flows through every part, so the resistor limits it wherever it is.
3. **Don't share one resistor between LEDs side by side (parallel).** Different colours need different voltages, so the current takes the easiest path. One LED gets most of it and the other stays dim or off.
4. **Each LED needs its own pin** if I want to control it separately. LEDs on the same pin always switch together.

### For the counter

| LED | Binary place | bitRead position | Pin |
|---|---|---|---|
| Yellow (leftmost) | 8s | 3 | 3 |
| Pink | 4s | 2 | 6 |
| Green | 2s | 1 | 4 |
| Blue (rightmost) | 1s | 0 | 5 |

4 LEDs = **4 pins + 4 resistors**, all sharing one GND rail.

---

## Part 3: How a breadboard is connected inside

![Inside a breadboard](breadboard-inside.svg)

Under the plastic there are **metal strips** with spring clips. Anything in the same strip is connected.

- Each numbered column, holes **a–e** = one strip (5 holes connected)
- Same column, holes **f–j** = a **different** strip
- The **middle gap** separates top and bottom (nothing crosses it unless I put a part across it)
- Neighbouring columns are **not** connected
- The **+ and − rails** are long strips that run the whole length → used for power and GND

**Same strip = connected. Different strip = not connected.**

Mistakes to avoid:
- Both LED legs in the same column → the current skips the LED (**short circuit**)
- A wire one column off → it touches the wrong part

"Rows" vs "columns" depends on which way you turn the board. The rule is what matters:
**5 holes in a line, on one side of the gap, are joined.**

### Wokwi tips

- **Hover** over a leg to see A or C, and which hole it is in
- **R** key = rotate a part
- **Ctrl + mouse scroll** = zoom in
- Click a wire to change its **colour** (makes checking easier)
- **diagram.json** tab shows exactly which pin each wire goes to

---

## Part 4: Code

### `setup()` vs `loop()`

- `setup()` runs **once**. Code put there runs one time and stops.
- `loop()` runs **again and again forever**.

My first counter was inside `setup()`, so it counted to 15 once and stopped.

### Turning several LEDs on at the same time

The Arduino runs each line in a tiny fraction of a second.
If I write several `digitalWrite` lines with **no `delay` between them**, they all look like they switch at the same time.
Put **one `delay` after the group**, not after each line.

### `for` loop

Repeats code while counting.

```
for ( start ; condition ; step ) {
    code to repeat
}
```

```cpp
for (int n = 0; n <= 15; n++) {
  // runs 16 times: n = 0, 1, 2 ... 15
}
```

| Part | Meaning |
|---|---|
| `int n = 0` | start: make a counter called n, begin at 0 (runs once) |
| `n <= 15` | condition: keep going while n is 15 or less |
| `n++` | step: after each round, add 1 to n (same as n = n + 1) |

### `bitRead(number, position)`

Looks inside a number and gives **1 or 0** for one binary digit.
Position is counted **from the right, starting at 0**.

| Code | Meaning | 11 = 1011 → answer |
|---|---|---|
| `bitRead(11, 0)` | 1s digit | 1 |
| `bitRead(11, 1)` | 2s digit | 1 |
| `bitRead(11, 2)` | 4s digit | 0 |
| `bitRead(11, 3)` | 8s digit | 1 |

### `if` / `else`

```cpp
if (x == 1) {
  // do this
} else {
  // do that
}
```

- Condition goes in **round brackets** `( )`
- Code goes in **curly braces** `{ }` (not a colon like Python)
- `=` means **put a value in** (assign)
- `==` means **are these equal?** (compare)

### Global vs local variables

- **Global:** made at the top, outside any function → every part of the code can use it
- **Local:** made inside a function (like `setup()`) → only that function can see it

Error message when a function can't see a variable:
`'blue' was not declared in this scope`

### My plan before coding (pseudocode)

1. Count the numbers: +1, +1, +1 (0 to 15)
2. For each number, look at each digit (each position)
3. Each position has a light
4. If the digit is 1 → light HIGH, else → LOW
5. Wait, then go to the next number

### Final code

```cpp
int yellow = 3;   // 8s
int green  = 4;   // 2s
int blue   = 5;   // 1s
int pink   = 6;   // 4s

void setup() {
  pinMode(yellow, OUTPUT);
  pinMode(green, OUTPUT);
  pinMode(blue, OUTPUT);
  pinMode(pink, OUTPUT);
}

void loop() {
  for (int n = 0; n <= 15; n++) {
    int b = bitRead(n, 0);   // 1s
    int g = bitRead(n, 1);   // 2s
    int p = bitRead(n, 2);   // 4s
    int y = bitRead(n, 3);   // 8s

    if (b == 1) { digitalWrite(blue, HIGH); }   else { digitalWrite(blue, LOW); }
    if (g == 1) { digitalWrite(green, HIGH); }  else { digitalWrite(green, LOW); }
    if (p == 1) { digitalWrite(pink, HIGH); }   else { digitalWrite(pink, LOW); }
    if (y == 1) { digitalWrite(yellow, HIGH); } else { digitalWrite(yellow, LOW); }

    delay(1000);   // show each number for 1 second
  }
}
```

The long version (16 blocks of `digitalWrite`) is kept in my code as comments, so I can compare.

---

## Part 5: Mistakes I made and fixed

| Mistake | Fix |
|---|---|
| `output`, `High`, `Low` | Must be capitals: `OUTPUT`, `HIGH`, `LOW` (Arduino is case-sensitive) |
| Counter code inside `setup()` | Moved it to `loop()` so it repeats forever |
| Python-style `if y = 1 :` | C++ style: `if (y == 1) { }` |
| Missing `;` after `bitRead` lines | Every statement ends with `;` |
| `pinMode` lines commented out | Removed the `//` so they run |
| Pin variables moved inside `setup()` | Moved back to the top (global) |
| Used old name `orange` | Changed to `yellow` everywhere |
| Missing `}` | Every `{` needs a matching `}`. A red wavy line points to the `{` without a match |
| Resistor and LED one column apart | Same column = same strip = connected |

---

## Challenge for next time

`HIGH` = 1 and `LOW` = 0, and `bitRead()` already gives 1 or 0.
Can each `if/else` block become **one line**?
